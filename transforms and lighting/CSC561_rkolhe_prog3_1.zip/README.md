# prog3

helper files for the intro cg class's third programming assignment
